package info.prog.agario.model.entity;

import info.prog.agario.model.entity.player.Cell;
import info.prog.agario.model.entity.player.PlayerGroup;
import javafx.animation.ScaleTransition;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.effect.Glow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class ExplosionPellet extends SpecialPellet {

    public ExplosionPellet(double x, double y) {
        super(x, y);
        this.radius = new SimpleDoubleProperty(50);
        this.setMass(0);

        Circle mainCircle = new Circle(x, y, 50);
        mainCircle.setFill(Color.GREEN);
        mainCircle.setStroke(Color.DARKGREEN);
        mainCircle.setStrokeWidth(6);
        mainCircle.getStrokeDashArray().addAll(5d, 10d);
        this.shape = mainCircle;
    }

    public void PlayEffect(Cell cell) {
        cell.divide();

    }

}
